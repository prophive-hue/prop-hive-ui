import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-PVRCY3EF.js";
import "./chunk-7ZDG6LXI.js";
import "./chunk-GRE5C4UV.js";
import "./chunk-2XUDQHIN.js";
import "./chunk-RQIOO3G3.js";
import "./chunk-FEDAEUWJ.js";
import "./chunk-N2CVKOQC.js";
import "./chunk-P6U2JBMQ.js";
import "./chunk-4MWRP73S.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
