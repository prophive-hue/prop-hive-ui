import { Component } from '@angular/core';
import {CardModule} from 'primeng/card';
import {NgStyle} from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-investor-dashboard',
  imports: [CardModule, NgStyle],
  templateUrl: './investor-dashboard.component.html',
  styleUrl: './investor-dashboard.component.css'
})
export class InvestorDashboardComponent {

  constructor(private router: Router) {
  }

  openProfileCompletion() {
    this.router.navigate(['investor/onboarding'])
  }
}
