import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';


export interface CreateProperty {
  title: string,
  location: string,
  category: string,
  description: string,
  developer: string,
  expectedRoi: number,
  totalInvestment: number,
  status: string,
  base64Images: Base64File[];
}

export interface Base64File {
  base64: string;
}


export interface Property {
  id: string,
  title: string,
  location: string,
  category: string,
  description: string,
  developer: string,
  expectedRoi: number,
  totalInvestment: number,
  status: string,
  imageUrls: string[];
}

export interface ResponseMessage {
  message: string;
}

export interface PropertyResponse {
  content: Property[];
  totalElements: number;
}

export interface Pagination{
  page: number;
  size: number;
}


@Injectable({
  providedIn: 'root'
})


export class AdminPropertiesService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:8080/api/v1';
  constructor() { }


  createProperty(propertyData: CreateProperty): Observable<ResponseMessage> {
    return this.http.post<ResponseMessage>(`${this.baseUrl}/property/create`, propertyData)
      .pipe(
        catchError(this.handleError)
      );
  }


  getAllProperties(paginator:Pagination): Observable<PropertyResponse> {
    return this.http.post<PropertyResponse>(`${this.baseUrl}/property/all/home`, paginator)
      .pipe(
        catchError(this.handleError)
      );
  }

  getProperty(id:string): Observable<Property> {
    return this.http.get<Property>(`${this.baseUrl}/property/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred';

    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = error.error?.message ||
        `Server returned code ${error.status}, error message: ${error.message}`;
    }

    console.error(errorMessage);
    return throwError(() => new Error(errorMessage));
  }
}
