import {Component, ViewChild} from '@angular/core';
import {ButtonModule} from 'primeng/button';
import {AutoFocusModule} from 'primeng/autofocus';
import {ProgressBarModule} from 'primeng/progressbar';
import {OverlayBadgeModule} from 'primeng/overlaybadge';
import {TabsModule} from 'primeng/tabs';
import {AvatarModule} from 'primeng/avatar';
import {AvatarGroupModule} from 'primeng/avatargroup';
import {AnimateOnScrollModule} from 'primeng/animateonscroll';
import {AccordionModule} from 'primeng/accordion';
import {AutoCompleteModule} from 'primeng/autocomplete';
import {BadgeModule} from 'primeng/badge';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import {BlockUIModule} from 'primeng/blockui';
import {CalendarModule} from 'primeng/calendar';
import {DatePickerModule} from 'primeng/datepicker';
import {CarouselModule} from 'primeng/carousel';
import {CascadeSelectModule} from 'primeng/cascadeselect';
import {ChartModule} from 'primeng/chart';
import {CheckboxModule} from 'primeng/checkbox';
import {ChipModule} from 'primeng/chip';
import {ColorPickerModule} from 'primeng/colorpicker';
import {ConfirmDialogModule} from 'primeng/confirmdialog';
import {ConfirmPopupModule} from 'primeng/confirmpopup';
import {ContextMenuModule} from 'primeng/contextmenu';
import {DataViewModule} from 'primeng/dataview';
import {DialogModule} from 'primeng/dialog';
import {DividerModule} from 'primeng/divider';
import {DeferModule} from 'primeng/defer';
import {DockModule} from 'primeng/dock';
import {DragDropModule} from 'primeng/dragdrop';
import {SelectModule} from 'primeng/select';
import {DynamicDialogModule} from 'primeng/dynamicdialog';
import {EditorModule} from 'primeng/editor';
import {FieldsetModule} from 'primeng/fieldset';
import {FileUploadModule} from 'primeng/fileupload';
import {FocusTrapModule} from 'primeng/focustrap';
import {GalleriaModule} from 'primeng/galleria';
import {IftaLabelModule} from 'primeng/iftalabel';
import {InplaceModule} from 'primeng/inplace';
import {InputMaskModule} from 'primeng/inputmask';
import {InputSwitchModule} from 'primeng/inputswitch';
import {InputTextModule} from 'primeng/inputtext';
import {TextareaModule} from 'primeng/textarea';
import {InputNumberModule} from 'primeng/inputnumber';
import {InputGroupModule} from 'primeng/inputgroup';
import {InputGroupAddonModule} from 'primeng/inputgroupaddon';
import {InputOtpModule} from 'primeng/inputotp';
import {ImageModule} from 'primeng/image';
import {ImageCompareModule} from 'primeng/imagecompare';
import {KnobModule} from 'primeng/knob';
import {ListboxModule} from 'primeng/listbox';
import {MegaMenuModule} from 'primeng/megamenu';
import {MenuModule} from 'primeng/menu';
import {MenubarModule} from 'primeng/menubar';
import {MeterGroupModule} from 'primeng/metergroup';
import {OrganizationChartModule} from 'primeng/organizationchart';
import {OrderListModule} from 'primeng/orderlist';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {PaginatorModule} from 'primeng/paginator';
import {PanelModule} from 'primeng/panel';
import {PanelMenuModule} from 'primeng/panelmenu';
import {PasswordModule} from 'primeng/password';
import {PickListModule} from 'primeng/picklist';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {RadioButtonModule} from 'primeng/radiobutton';
import {RatingModule} from 'primeng/rating';
import {SelectButtonModule} from 'primeng/selectbutton';
import {SidebarModule} from 'primeng/sidebar';
import {ScrollerModule} from 'primeng/scroller';
import {ScrollPanelModule} from 'primeng/scrollpanel';
import {ScrollTopModule} from 'primeng/scrolltop';
import {SkeletonModule} from 'primeng/skeleton';
import {SliderModule} from 'primeng/slider';
import {SpeedDialModule} from 'primeng/speeddial';
import {SplitterModule} from 'primeng/splitter';
import {StepperModule} from 'primeng/stepper';
import {SplitButtonModule} from 'primeng/splitbutton';
import {StepsModule} from 'primeng/steps';
import {TableModule} from 'primeng/table';
import {TabMenuModule} from 'primeng/tabmenu';
import {TagModule} from 'primeng/tag';
import {TerminalModule} from 'primeng/terminal';
import {TieredMenuModule} from 'primeng/tieredmenu';
import {TimelineModule} from 'primeng/timeline';
import {ToastModule} from 'primeng/toast';
import {ToggleButtonModule} from 'primeng/togglebutton';
import {ToggleSwitchModule} from 'primeng/toggleswitch';
import {ToolbarModule} from 'primeng/toolbar';
import {TooltipModule} from 'primeng/tooltip';
import {TreeModule} from 'primeng/tree';
import {TreeSelectModule} from 'primeng/treeselect';
import {TreeTableModule} from 'primeng/treetable';
import {CardModule} from 'primeng/card';
import {RippleModule} from 'primeng/ripple';
import {StyleClassModule} from 'primeng/styleclass';
import {FloatLabelModule} from 'primeng/floatlabel';
import {IconFieldModule} from 'primeng/iconfield';
import {InputIconModule} from 'primeng/inputicon';
import {DrawerModule} from 'primeng/drawer';
import {FormBuilder, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {MessageService} from 'primeng/api';
import {Pagination} from '../services/admin-properties.service';
import {DialogDeveloperCreateComponent} from '../dialog-developer-create/dialog-developer-create.component';
import {AdminDevelopersService, CreateDeveloper, Developer} from '../services/admin-developers.service';
import {RegisterRequest} from '../../auth/services/auth.service';

@Component({
  selector: 'app-developers',
  imports: [
    ButtonModule,
    AvatarModule,
    AvatarGroupModule,
    AnimateOnScrollModule,
    TabsModule,
    FormsModule,
    ReactiveFormsModule,
    AccordionModule,
    AutoCompleteModule,
    BadgeModule,
    BreadcrumbModule,
    BlockUIModule,
    ButtonModule,
    CalendarModule,
    DatePickerModule,
    CarouselModule,
    CascadeSelectModule,
    ChartModule,
    CheckboxModule,
    ChipModule,
    ColorPickerModule,
    ConfirmDialogModule,
    ConfirmPopupModule,
    ContextMenuModule,
    DataViewModule,
    DialogModule,
    DividerModule,
    DrawerModule,
    DeferModule,
    DockModule,
    DragDropModule,
    SelectModule,
    DynamicDialogModule,
    EditorModule,
    FieldsetModule,
    FileUploadModule,
    FocusTrapModule,
    GalleriaModule,
    IftaLabelModule,
    InplaceModule,
    InputMaskModule,
    InputSwitchModule,
    InputTextModule,
    TextareaModule,
    InputNumberModule,
    InputGroupModule,
    InputGroupAddonModule,
    InputOtpModule,
    ImageModule,
    ImageCompareModule,
    KnobModule,
    ListboxModule,
    MegaMenuModule,
    MenuModule,
    MenubarModule,
    MeterGroupModule,
    OrganizationChartModule,
    OrderListModule,
    OverlayPanelModule,
    PaginatorModule,
    PanelModule,
    PanelMenuModule,
    PasswordModule,
    PickListModule,
    ProgressSpinnerModule,
    ProgressBarModule,
    RadioButtonModule,
    RatingModule,
    SelectButtonModule,
    SidebarModule,
    ScrollerModule,
    ScrollPanelModule,
    ScrollTopModule,
    SkeletonModule,
    SliderModule,
    SpeedDialModule,
    SplitterModule,
    StepperModule,
    SplitButtonModule,
    StepsModule,
    TableModule,
    TabMenuModule,
    TagModule,
    TerminalModule,
    TieredMenuModule,
    TimelineModule,
    ToastModule,
    ToggleButtonModule,
    ToggleSwitchModule,
    ToolbarModule,
    TooltipModule,
    TreeModule,
    TreeSelectModule,
    TreeTableModule,
    CardModule,
    RippleModule,
    StyleClassModule,
    FloatLabelModule,
    IconFieldModule,
    InputIconModule,
    AutoFocusModule,
    OverlayBadgeModule,
    ProgressBarModule,
    DialogDeveloperCreateComponent
  ],
  providers: [MessageService],
  templateUrl: './developers.component.html',
  styleUrl: './developers.component.css'
})
export class DevelopersComponent {


  loadDevelopersLazy($event: any) {

    const currentPage = ($event.first / $event.rows);
    this.loading = true;


    this.page = currentPage;
    this.size = $event.rows;

    console.log('page: ' + this.page);
    console.log('size: ' + this.size);

    this.getAllDevelopers();

    this.loading = false;
  }

  @ViewChild('dialog') dialogComponent!: DialogDeveloperCreateComponent;


  statuses!: any[];

  loading: boolean = true;

  activityValues: number[] = [0, 100];

  developers: Developer[] = [];

  totalElements: number = 0;
  page: number = 0;
  size: number = 5;


  constructor(private developersService: AdminDevelopersService, private messageService: MessageService) {
  }

  ngOnInit() {
    this.getAllDevelopers();
  }


  getSeverity(status: string) {
    switch (status) {
      case 'Property Developer':
        return 'success';

      case 'Construction Company':
        return 'info';

      case 'Real Estate Agency':
        return 'warn';

      case 'Architecture Firm':
        return null;
    }


    return ''
  }

  getAllDevelopers() {
    const paginator: Pagination = {
      page: this.page,
      size: this.size
    }

    console.log("paginator: " + paginator.size);

    this.developersService.getAllDevelopers(paginator).subscribe({
      next: (response) => {
        console.log('Login successful', response);
        this.developers = response.content;
        this.totalElements = response.totalElements;
        this.loading = false;
        // Navigate to dashboard or home page after login
        // this.router.navigate(['/dashboard']);
      },
      error: (error: Error) => {
        // this.errorMessage = error.message;
        this.loading = false;
      }
    });
  }


  handleCreate(data: any) {
    if (data) {
      console.log('Resource created:', data);
      // TODO: Persist data to a service or backend
      const createUser: RegisterRequest = {
        email: data.userEmail,
        password: data.password,
        name: data.userFirstName,
        surname: data.userSurname,
        phone: data.userPhone
      }


      const createDeveloper: CreateDeveloper = {
        companyName: data.companyName,
        email: data.companyEmail,
        phone: data.companyPhone,
        developerType: data.companyType,
        yearsExperience: data.yearsExperience,
        companyDescription: data.description,
        contactPerson: createUser
      };

      this.loading = true;
      this.developersService.createDeveloper(createDeveloper).subscribe({
        next: (response) => {
          console.log('developer created successfully', response);
          this.loading = false;
          this.getAllDevelopers();
          this.messageService.add({
            severity: 'success',
            summary: "Developer Creation",
            detail: response.message,
            key: 'tl',
            life: 10000
          });
          //Navigate to dashboard or home page after login
          //this.router.navigate(['/dashboard']);
        },
        error: (error: Error) => {
          this.messageService.add({
            severity: 'warn',
            summary: "Error creating developer",
            detail: error.message,
            key: 'tl',
            life: 10000
          });
          //this.errorMessage = error.message;
          this.loading = false;
        }
      });
    }
  }
}
