import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SideNavComponent } from '../side-nav/side-nav.component';
import {HeaderComponent} from '../../shared/header/header.component';

@Component({
  selector: 'app-admin-layout',
  imports: [CommonModule, RouterOutlet, SideNavComponent, HeaderComponent],
  templateUrl: './admin-layout.component.html',
  styleUrl: './admin-layout.component.css'
})
export class AdminLayoutComponent {

}
