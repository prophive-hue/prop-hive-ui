import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../auth/services/auth.service';
import {TopNavComponent} from '../top-nav/top-nav.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule, TopNavComponent],
  templateUrl: './header.component.html',
  styles: [`
    .navbar-nav .nav-link.active {
      font-weight: bold;
      color: #0d6efd;
    }
  `]
})
export class HeaderComponent implements OnInit {
  isLoggedIn = false;

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    // Check auth status on initialization
    this.isLoggedIn = this.authService.isLoggedIn();
  }

  logout(): void {
    this.authService.logout().subscribe(() => {
      window.location.href = '/'; // Hard reload to reset application state
    });
  }
}
